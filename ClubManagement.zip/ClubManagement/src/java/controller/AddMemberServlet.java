package controller;

import dao.UserDAO;
import model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class AddMemberServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddMemberServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddMemberServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        UserDAO userDAO = new UserDAO();

        if (userDAO.isEmailExists(email)) {
            request.setAttribute("errorMessage", "Email đã tồn tại! Vui lòng chọn email khác.");
            request.getRequestDispatcher("views/addMember.jsp").forward(request, response);
            return; 
        }


        if (userDAO.addUser(new User(0, fullName, email, password, role))) {
            response.sendRedirect(request.getContextPath() + "/views/manageMembers.jsp");
        } else {
            request.setAttribute("errorMessage", "Thêm thành viên thất bại!");
            request.getRequestDispatcher("views/addMember.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
