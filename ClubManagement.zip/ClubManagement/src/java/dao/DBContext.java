package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBContext {
    private static DBContext instance;
    private Connection connection;

    private static final String USER = "sa";
    private static final String PASSWORD = "18112004";
    private static final String URL = "jdbc:sqlserver://DESKTOP-0JVRHH0:1433;databaseName=ClubManagement";

    private DBContext() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Lỗi khi kết nối CSDL!");
        }
    }


    public static synchronized DBContext getInstance() {
        if (instance == null) {
            instance = new DBContext();
        }
        return instance;
    }

  
    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Không thể kết nối lại với CSDL!");
        }
        return connection;
    }
}
