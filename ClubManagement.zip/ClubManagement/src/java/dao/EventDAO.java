package dao;

import model.Event;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventDAO {

    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        String query = "SELECT * FROM Events ORDER BY EventDate DESC";

        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                events.add(new Event(rs.getInt("EventID"), rs.getString("EventName"),
                        rs.getString("Description"), rs.getTimestamp("EventDate"),
                        rs.getString("Location")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    public Event getEventById(int eventID) {
        String query = "SELECT * FROM Events WHERE EventID = ?";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Event(rs.getInt("EventID"), rs.getString("EventName"),
                        rs.getString("Description"), rs.getTimestamp("EventDate"),
                        rs.getString("Location"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean addEvent(Event event) {
        String query = "INSERT INTO Events (EventName, Description, EventDate, Location) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, event.getEventName());
            stmt.setString(2, event.getDescription());
            stmt.setTimestamp(3, event.getEventDate());
            stmt.setString(4, event.getLocation());

            int rowsAffected = stmt.executeUpdate();
            System.out.println(" Rows affected: " + rowsAffected);
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.out.println("Lỗi SQL khi thêm sự kiện: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateEvent(Event event) {
        String query = "UPDATE Events SET EventName = ?, Description = ?, EventDate = ?, Location = ? WHERE EventID = ?";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, event.getEventName());
            stmt.setString(2, event.getDescription());
            stmt.setTimestamp(3, event.getEventDate());
            stmt.setString(4, event.getLocation());
            stmt.setInt(5, event.getEventID());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteEvent(int eventID) {
        String query = "DELETE FROM Events WHERE EventID = ?";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
