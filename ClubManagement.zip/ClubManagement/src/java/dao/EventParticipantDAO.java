package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EventParticipantDAO {

    public boolean isUserRegistered(int userID, int eventID) {
        String query = "SELECT * FROM EventParticipants WHERE UserID = ? AND EventID = ?";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userID);
            stmt.setInt(2, eventID);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean unregisterEvent(int userID, int eventID) {
        String query = "DELETE FROM EventParticipants WHERE UserID = ? AND EventID = ?";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userID);
            stmt.setInt(2, eventID);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean registerEvent(int userID, int eventID) {
        if (isUserRegistered(userID, eventID)) {
            return false;
        }

        String query = "INSERT INTO EventParticipants (EventID, UserID, Status) VALUES (?, ?, 'Registered')";
        try (Connection conn = DBContext.getInstance().getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventID);
            stmt.setInt(2, userID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
