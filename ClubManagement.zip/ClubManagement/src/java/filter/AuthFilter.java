package filter;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*") 
public class AuthFilter implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        String uri = req.getRequestURI();

   
        if (uri.endsWith("views/login.jsp") || uri.endsWith("login") || uri.endsWith("css") || uri.endsWith("js")) {
            chain.doFilter(request, response);
            return;
        }


        if (user == null) {
            res.sendRedirect("views/login.jsp");
            return;
        }


        if (user.getRole().equals("Member") && (uri.contains("manageMembers") || uri.contains("manageEvents") || uri.contains("addevent") || uri.contains("editevent") || uri.contains("deleteevent"))) {
            res.sendRedirect("views/dashboard.jsp?error=Bạn không có quyền truy cập!");
            return;
        }

        chain.doFilter(request, response);
    }
}
